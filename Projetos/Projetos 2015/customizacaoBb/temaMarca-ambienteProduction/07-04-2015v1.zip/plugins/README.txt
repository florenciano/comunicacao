List of names of building block folders in the package and their respective long names

Bb-discussionboard - Discussões
Bb-wiki - Wikis
bb-assessment - Avaliações
bb-blogs-journals - Blogs e diários
bb-grading - Grading
bb-selfpeer - Auto-avaliação e Avaliação de colegas
