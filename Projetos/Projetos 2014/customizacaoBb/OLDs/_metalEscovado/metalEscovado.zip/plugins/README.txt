List of names of building block folders in the package and their respective long names

Bb-discussionboard - Discussões
Bb-wiki - Wikis
bb-assessment - Avaliações
bb-blogs-journals - Blogs e diários
bb-collaborate - Blackboard Collaborate
bb-grading - Grading
bb-portfolio - Portfólios
bb-selfpeer - Auto-avaliação e Avaliação de colegas
bb-student-preview - Visualização do aluno
