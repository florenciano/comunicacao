$(function(){
    
    // HOME
	// // // // // // // // // // // // // // // // // // // // // // //
	
	"use strict";

	console.log(true);

});
